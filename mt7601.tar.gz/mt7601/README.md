## MT7601U Linux driver

*Now that Kernel 4.2 has been released which contains [a driver for mt7601u](https://github.com/torvalds/linux/tree/master/drivers/net/wireless/mediatek/mt7601u), this repository is now deprecated.*


### Credits

**Source code:** (c) Copyright 2002-2013, MediaTek Inc. (released under GPLv2)

**Patch:** @poma at [linux-wireless](http://wireless.kernel.org/en/developers/MailingLists) mailing list
